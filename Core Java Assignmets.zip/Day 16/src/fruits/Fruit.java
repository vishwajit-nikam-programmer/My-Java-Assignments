package fruits;

public class Fruit {
	public void taste() {
		System.out.println("unknown taste!");
	}
}
