package fruits;

public class Kesar extends Mango {
	
}
