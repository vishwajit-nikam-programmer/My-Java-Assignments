package fruits;

public class Alphonso extends Mango {
	
}
