package functional_prog;

public class Adder implements Computable {

	@Override
	public double compute(double a, double b) {
		// TODO Auto-generated method stub
		return a+b;
	}

}
