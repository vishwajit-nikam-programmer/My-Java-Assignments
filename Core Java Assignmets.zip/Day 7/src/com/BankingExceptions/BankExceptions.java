package com.BankingExceptions;

public class BankExceptions extends Exception{

    //Contructor
    public BankExceptions(String Message) {
        super(message);
    }
       
}
